import io
import json
import re
from typing import List, Tuple, Optional

import pdfplumber
from groq import Groq
from gtts import gTTS


# -----------------------------
# Resume parsing
# -----------------------------
def extract_resume_text(file) -> str:
    """
    Extract text from a PDF resume using pdfplumber.
    Accepts a file-like object from Streamlit uploader.
    """
    try:
        text_parts = []
        with pdfplumber.open(file) as pdf:
            for page in pdf.pages:
                t = page.extract_text() or ""
                if t.strip():
                    text_parts.append(t)
        return "\n".join(text_parts).strip()
    except Exception as e:
        return f"__ERROR__: Failed to read PDF ({e})"


# -----------------------------
# TTS (question -> mp3 bytes)
# -----------------------------
def tts_question_to_mp3_bytes(question_text: str) -> Optional[bytes]:
    """
    Convert a question string to MP3 bytes using gTTS.
    Returns None if TTS fails (e.g., offline).
    """
    try:
        tts = gTTS(text=question_text, lang="en")
        buf = io.BytesIO()
        tts.write_to_fp(buf)
        buf.seek(0)
        return buf.read()
    except Exception:
        return None


# -----------------------------
# STT (optional, via Groq Whisper)
# -----------------------------
def transcribe_audio_with_groq(client: Groq, audio_bytes: bytes, filename: str = "answer.wav") -> Optional[str]:
    """
    Transcribe recorded audio using Groq Whisper (if available).
    Returns transcript text or None if transcription fails.
    """
    try:
        # Groq SDK follows OpenAI-like API for transcriptions.
        # If SDK changes, this will gracefully fail and return None.
        resp = client.audio.transcriptions.create(
            model="whisper-large-v3",
            file=("answer.wav", audio_bytes, "audio/wav"),
        )
        # Some SDKs return .text, others .transcript; handle both.
        return getattr(resp, "text", None) or getattr(resp, "transcript", None)
    except Exception:
        return None


# -----------------------------
# Question generation (Groq)
# -----------------------------
def generate_questions(
    client: Groq,
    resume_text: str,
    job_role: str,
    difficulty: str,
    n_questions: int = 14,
) -> List[str]:
    """
    Generate exactly n_questions tailored interview questions based on resume, role, and difficulty.
    """
    prompt = f"""
You are an expert interviewer for the role: {job_role}.
Difficulty should be {difficulty}.

Given the resume content below, produce EXACTLY {n_questions} targeted interview questions.
Rules:
- Output only a plain numbered list (1., 2., ...) with one question per line.
- Questions must reflect the candidate's experience, projects, and skills.
- No extra commentary before or after the list.

Resume:
{resume_text[:6000]}
"""
    res = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        temperature=0.6 if difficulty == "Easy" else 0.75 if difficulty == "Medium" else 0.9,
        max_tokens=900,
        messages=[
            {"role": "system", "content": "You write crisp, on-target interview questions."},
            {"role": "user", "content": prompt},
        ],
    )
    raw = res.choices[0].message.content.strip()

    # Parse numbered lines like "1. ..." or "1) ...", fallback to lines
    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    questions = []
    for ln in lines:
        m = re.match(r"^\s*(?:\d{1,2}[\.\)]\s*|\-\s*)(.+)$", ln)
        questions.append(m.group(1).strip() if m else ln)

    # Clean + enforce length
    questions = [q for q in questions if len(q) > 3]
    if len(questions) < n_questions:
        # pad generic if model under-delivers
        pad = n_questions - len(questions)
        questions += [f"Tell me more about an impactful project you mentioned and your role in it. (auto-fill {i+1})" for i in range(pad)]
    elif len(questions) > n_questions:
        questions = questions[:n_questions]

    return questions


# -----------------------------
# Scoring / evaluation (Groq)
# -----------------------------
def evaluate_answers(
    client: Groq,
    resume_text: str,
    job_role: str,
    questions: List[str],
    answers: List[str],
) -> Tuple[int, str]:
    """
    Ask model to score each Q/A (0–10) and produce an overall 0–100.
    Returns (overall_score_int, markdown_feedback_str).
    """
    qa = [{"q": q, "a": (answers[i] if i < len(answers) else "")} for i, q in enumerate(questions)]

    system = "You are a strict but fair interviewer who returns JSON first."
    user_payload = {
        "instruction": "Score each answer (0-10) with short feedback, then compute overall (0-100).",
        "job_role": job_role,
        "resume_excerpt": resume_text[:5000],
        "qa": qa,
        "format": "Return ONLY JSON in this schema: "
                  '{"per_question":[{"q":str,"a":str,"score":int,"feedback":str}],'
                  '"overall":{"total":int,"summary":str}}',
    }

    res = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        temperature=0.2,
        max_tokens=1400,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": json.dumps(user_payload)},
        ],
    )
    raw = res.choices[0].message.content.strip()

    # Try parse JSON (strip code fences)
    cleaned = raw
    m = re.match(r"^```(?:json)?\s*(.*?)\s*```$", raw, flags=re.DOTALL | re.IGNORECASE)
    if m:
        cleaned = m.group(1).strip()

    try:
        payload = json.loads(cleaned)
    except Exception:
        # Fallback if the model didn't return valid JSON
        nonempty = sum(1 for a in answers if a and a.strip())
        approx = min(100, max(0, int((nonempty / max(1, len(questions))) * 70) + 30))
        md = f"### 📊 Evaluation (Fallback)\n**Overall Score:** {approx}/100\n\nCould not parse detailed feedback."
        return approx, md

    per_q = payload.get("per_question", [])
    overall = payload.get("overall", {})
    total = int(overall.get("total", 0))
    summary = overall.get("summary", "")

    # Build markdown report
    lines = ["### 📊 Evaluation Report", f"**Overall Score:** {total}/100", ""]
    lines.append("#### Per-Question Feedback")
    for i, item in enumerate(per_q, start=1):
        qi = item.get("q", "")
        ai = item.get("a", "")
        sc = item.get("score", 0)
        fb = item.get("feedback", "")
        lines.append(f"**Q{i}.** {qi}")
        lines.append(f"- **Your Answer:** {ai if ai else '*No answer provided*'}")
        lines.append(f"- **Score:** {sc}/10")
        lines.append(f"- **Feedback:** {fb}")
        lines.append("")

    if summary:
        lines.append("#### Summary")
        lines.append(summary)

    return max(0, min(100, total)), "\n".join(lines)
