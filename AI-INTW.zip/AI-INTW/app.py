import os
import io
import streamlit as st
from dotenv import load_dotenv
from groq import Groq
from streamlit_mic_recorder import mic_recorder

from utils import (
    extract_resume_text,
    tts_question_to_mp3_bytes,
    transcribe_audio_with_groq,
    generate_questions,
    evaluate_answers,
)

# -------------------- Setup --------------------
st.set_page_config(page_title="AI Interview Simulator", page_icon="🎤", layout="wide")
load_dotenv()
API_KEY = os.getenv("GROQ_API_KEY")

if not API_KEY:
    st.error("GROQ_API_KEY not found. Create a .env file with GROQ_API_KEY=your_key.")
    st.stop()

client = Groq(api_key=API_KEY)

# -------------------- Styling --------------------
st.markdown("""
<style>
    /* Main theme and layout - Dark Theme */
    .main {
        background: linear-gradient(135deg, #1a202c 0%, #2d3748 100%);
        min-height: 100vh;
    }
    
    .block-container {
        max-width: 1200px;
        padding: 2rem 1rem;
        background: rgba(26, 32, 44, 0.95);
        border-radius: 20px;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        margin: 2rem auto;
        backdrop-filter: blur(10px);
        border: 1px solid #4a5568;
    }
    
    /* Typography */
    .stApp {
        background: #1a202c !important;
    }
    
    h1 {
        color: #f7fafc !important;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important;
        font-weight: 700 !important;
        text-align: center !important;
        margin-bottom: 0.5rem !important;
        font-size: 3rem !important;
        background: linear-gradient(135deg, #63b3ed 0%, #4299e1 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    h2, h3, h4, h5 {
        color: #e2e8f0 !important;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important;
        font-weight: 600 !important;
    }
    
    p, div, span, label {
        color: #cbd5e0 !important;
    }
    
    .subtitle {
        text-align: center;
        color: #a0aec0 !important;
        font-size: 1.2rem;
        margin-bottom: 3rem;
        font-weight: 400;
    }
    
    /* Cards and containers */
    .modern-card {
        background: #2d3748;
        border: 1px solid #4a5568;
        border-radius: 16px;
        padding: 2rem;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
        transition: all 0.3s ease;
        margin-bottom: 1.5rem;
        position: relative;
        overflow: hidden;
    }
    
    .modern-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #63b3ed 0%, #4299e1 100%);
    }
    
    .modern-card:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
    }
    
    .question-card {
        background: linear-gradient(135deg, #2d3748 0%, #4a5568 100%);
        border: 2px solid #63b3ed;
        border-radius: 20px;
        padding: 2.5rem;
        margin: 2rem 0;
        box-shadow: 0 6px 24px rgba(0, 0, 0, 0.25);
        position: relative;
    }
    
    .question-card::before {
        content: '💬';
        position: absolute;
        top: -10px;
        left: 20px;
        background: #63b3ed;
        padding: 10px;
        border-radius: 50%;
        font-size: 1.2rem;
    }
    
    /* Buttons */
    .stButton > button {
        background: linear-gradient(135deg, #63b3ed 0%, #4299e1 100%) !important;
        color: #1a202c !important;
        border: none !important;
        border-radius: 12px !important;
        padding: 0.75rem 2rem !important;
        font-weight: 600 !important;
        font-size: 1rem !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 4px 12px rgba(99, 179, 237, 0.3) !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
    }
    
    .stButton > button:hover {
        transform: translateY(-1px) !important;
        box-shadow: 0 6px 18px rgba(99, 179, 237, 0.4) !important;
    }
    
    .stButton > button:active {
        transform: translateY(0px) !important;
    }
    
    /* Secondary buttons */
    .secondary-btn button {
        background: #4a5568 !important;
        color: #e2e8f0 !important;
        border: 2px solid #718096 !important;
    }
    
    .secondary-btn button:hover {
        background: #2d3748 !important;
        border-color: #4a5568 !important;
    }
    
    /* Pills and badges */
    .status-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem 1rem;
        border-radius: 25px;
        background: linear-gradient(135deg, #63b3ed 0%, #4299e1 100%);
        color: #1a202c;
        font-weight: 600;
        font-size: 0.9rem;
        margin: 0.25rem;
        box-shadow: 0 2px 8px rgba(99, 179, 237, 0.3);
    }
    
    /* Progress bar */
    .stProgress > div > div > div {
        background: linear-gradient(90deg, #63b3ed 0%, #4299e1 100%) !important;
        border-radius: 10px !important;
        height: 12px !important;
    }
    
    .stProgress > div > div {
        background: #4a5568 !important;
        border-radius: 10px !important;
        height: 12px !important;
    }
    
    /* Form elements - Fixed for dark theme visibility */
    .stSelectbox > div > div {
        border: 2px solid #4a5568 !important;
        border-radius: 12px !important;
        background: #2d3748 !important;
        color: #e2e8f0 !important;
    }
    
    .stSelectbox > div > div > div {
        color: #e2e8f0 !important;
        background: #2d3748 !important;
    }
    
    .stSelectbox > div > div:focus-within {
        border-color: #63b3ed !important;
        box-shadow: 0 0 0 3px rgba(99, 179, 237, 0.2) !important;
    }
    
    .stSelectbox label {
        color: #cbd5e0 !important;
        font-weight: 600 !important;
    }
    
    /* Fix selectbox dropdown options visibility */
    .stSelectbox [data-baseweb="select"] > div {
        background-color: #2d3748 !important;
        color: #e2e8f0 !important;
    }
    
    .stSelectbox [data-baseweb="popover"] {
        background-color: #2d3748 !important;
        border: 1px solid #4a5568 !important;
    }
    
    .stSelectbox [role="option"] {
        background-color: #2d3748 !important;
        color: #e2e8f0 !important;
    }
    
    .stSelectbox [role="option"]:hover {
        background-color: #4a5568 !important;
    }
    
    .stSelectbox [aria-selected="true"] {
        background-color: #63b3ed !important;
        color: #1a202c !important;
    }
    
    /* Text input fields */
    .stTextInput > div > div > input {
        background: #2d3748 !important;
        border: 2px solid #4a5568 !important;
        border-radius: 12px !important;
        color: #e2e8f0 !important;
        font-family: 'Inter', sans-serif !important;
        font-size: 1rem !important;
        padding: 1rem !important;
    }
    
    .stTextInput > div > div > input:focus {
        border-color: #81e6d9 !important;
        box-shadow: 0 0 0 3px rgba(129, 230, 217, 0.1) !important;
    }
    
    .stTextInput label {
        color: #e2e8f0 !important;
        font-weight: 600 !important;
    }

    .stTextArea > div > div > textarea {
        border: 2px solid #4a5568 !important;
        border-radius: 12px !important;
        background: #2d3748 !important;
        color: #e2e8f0 !important;
        font-family: 'Inter', sans-serif !important;
        font-size: 1rem !important;
        padding: 1rem !important;
    }
    
    .stTextArea > div > div > textarea:focus {
        border-color: #63b3ed !important;
        box-shadow: 0 0 0 3px rgba(99, 179, 237, 0.2) !important;
    }
    
    .stTextArea label {
        color: #cbd5e0 !important;
        font-weight: 600 !important;
    }
    
    /* File uploader */
    .stFileUploader > div {
        border: 2px dashed #4a5568 !important;
        border-radius: 12px !important;
        background: #2d3748 !important;
        padding: 2rem !important;
        transition: all 0.3s ease !important;
    }
    
    .stFileUploader > div:hover {
        border-color: #63b3ed !important;
        background: #4a5568 !important;
    }
    
    .stFileUploader label {
        color: #cbd5e0 !important;
        font-weight: 600 !important;
    }
    
    /* Metrics */
    .stMetric {
        background: #2d3748 !important;
        border: 1px solid #4a5568 !important;
        border-radius: 16px !important;
        padding: 1.5rem !important;
        text-align: center !important;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2) !important;
    }
    
    .stMetric > div {
        color: #e2e8f0 !important;
    }
    
    .stMetric label {
        color: #cbd5e0 !important;
    }
    
    /* Audio player */
    .stAudio {
        margin: 1rem 0 !important;
    }
    
    /* Success/error messages */
    .stSuccess {
        background: linear-gradient(135deg, #48bb78 0%, #38a169 100%) !important;
        border: none !important;
        border-radius: 12px !important;
        color: white !important;
    }
    
    .stWarning {
        background: linear-gradient(135deg, #ed8936 0%, #dd6b20 100%) !important;
        border: none !important;
        border-radius: 12px !important;
        color: white !important;
    }
    
    .stError {
        background: linear-gradient(135deg, #f56565 0%, #e53e3e 100%) !important;
        border: none !important;
        border-radius: 12px !important;
        color: white !important;
    }
    
    .stInfo {
        background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%) !important;
        border: none !important;
        border-radius: 12px !important;
        color: white !important;
    }
    
    /* Hide default styling */
    .stDeployButton {display: none;}
    header[data-testid="stHeader"] {display: none;}
    .stDecoration {display: none;}
    
    /* Additional dark theme fixes */
    .stMarkdown {
        color: #cbd5e0 !important;
    }
    
    .stSidebar {
        background: #1a202c !important;
    }
    
    .stSidebar > div {
        background: #1a202c !important;
    }
    
    .stRadio > div {
        color: #cbd5e0 !important;
    }
    
    .stRadio > div > label {
        color: #cbd5e0 !important;
    }
    
    .stCheckbox > div {
        color: #cbd5e0 !important;
    }
    
    .stCheckbox > div > label {
        color: #cbd5e0 !important;
    }
    
    /* Fix for all text inputs */
    .stTextInput > div > div > input {
        background: #2d3748 !important;
        color: #e2e8f0 !important;
        border: 2px solid #4a5568 !important;
    }
    
    .stTextInput > div > div > input:focus {
        border-color: #63b3ed !important;
        box-shadow: 0 0 0 3px rgba(99, 179, 237, 0.2) !important;
    }
    
    .stTextInput label {
        color: #cbd5e0 !important;
    }
    
    /* Fix number input */
    .stNumberInput > div > div > input {
        background: #2d3748 !important;
        color: #e2e8f0 !important;
        border: 2px solid #4a5568 !important;
    }
    
    .stNumberInput label {
        color: #cbd5e0 !important;
    }
    
    /* Custom animations */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .fade-in {
        animation: fadeIn 0.6s ease-out;
    }
</style>
""", unsafe_allow_html=True)

# -------------------- Session --------------------
if "stage" not in st.session_state:
    st.session_state.stage = "landing"  # landing -> interview -> results

for key in ["role", "difficulty", "resume_text", "questions", "answers", "q_idx", "report", "score"]:
    st.session_state.setdefault(key, None)

# -------------------- Landing --------------------
if st.session_state.stage == "landing":
    st.markdown("<div class='fade-in'>", unsafe_allow_html=True)
    st.markdown("<h1>AI Interview Simulator</h1>", unsafe_allow_html=True)
    st.markdown("<p class='subtitle'>Upload your resume, select your target role & difficulty level. Our AI will generate personalized questions and provide detailed feedback on your performance.</p>", unsafe_allow_html=True)
    
    # Feature highlights
    st.markdown("""
    <div style='text-align: center; margin: 2rem 0;'>
        <div style='display: inline-flex; gap: 2rem; flex-wrap: wrap; justify-content: center;'>
            <div style='display: flex; align-items: center; gap: 0.5rem; color: #4a5568;'>
                <span style='font-size: 1.5rem;'>🎯</span>
                <span>Tailored Questions</span>
            </div>
            <div style='display: flex; align-items: center; gap: 0.5rem; color: #4a5568;'>
                <span style='font-size: 1.5rem;'>🎙️</span>
                <span>Voice Recording</span>
            </div>
            <div style='display: flex; align-items: center; gap: 0.5rem; color: #4a5568;'>
                <span style='font-size: 1.5rem;'>📊</span>
                <span>Detailed Analytics</span>
            </div>
            <div style='display: flex; align-items: center; gap: 0.5rem; color: #4a5568;'>
                <span style='font-size: 1.5rem;'>🔊</span>
                <span>Text-to-Speech</span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Main configuration section
    col1, col2 = st.columns([1, 1], gap="large")
    
    with col1:
        st.markdown("<div class='modern-card fade-in'>", unsafe_allow_html=True)
        st.markdown("### 🎯 Interview Configuration")
        
        st.markdown("**Select your target role:**")
        st.session_state.role = st.selectbox(
            "Job Role", 
            [
                "Software Engineer", 
                "Data Scientist", 
                "ML Engineer", 
                "Backend Developer",
                "Frontend Developer", 
                "DevOps Engineer",
                "Full Stack Developer",
                "Product Manager",
                "Data Analyst"
            ],
            label_visibility="collapsed"
        )
        
        st.markdown("**Choose difficulty level:**")
        difficulty_options = ["Easy", "Medium", "Hard"]
        st.session_state.difficulty = st.selectbox(
            "Difficulty", 
            difficulty_options, 
            index=1,
            label_visibility="collapsed"
        )
        
        # Difficulty description
        difficulty_descriptions = {
            "Easy": "Basic concepts and fundamental questions",
            "Medium": "Intermediate topics with some technical depth", 
            "Hard": "Advanced concepts and challenging scenarios"
        }
        st.markdown(f"<p style='color: #718096; font-size: 0.9rem; margin-top: 0.5rem;'>{difficulty_descriptions[st.session_state.difficulty]}</p>", unsafe_allow_html=True)
        
        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        st.markdown("<div class='modern-card fade-in'>", unsafe_allow_html=True)
        st.markdown("### 📄 Resume Upload")
        
        uploaded = st.file_uploader(
            "Upload your resume (PDF format)", 
            type=["pdf"],
            help="Upload a PDF file containing your resume. This will be used to generate personalized questions."
        )
        
        if uploaded:
            with st.spinner("Processing your resume..."):
                text = extract_resume_text(uploaded)
                if text.startswith("__ERROR__"):
                    st.error(text.replace("__ERROR__:", "").strip())
                else:
                    st.session_state.resume_text = text
                    st.success("✅ Resume processed successfully!")
                    
                    with st.expander("📖 Resume Preview (First 800 characters)"):
                        preview_text = text[:800] + ("..." if len(text) > 800 else "")
                        st.markdown(f"<div style='background: #2d3748; padding: 1rem; border-radius: 8px; font-family: monospace; font-size: 0.9rem; color: #e2e8f0;'>{preview_text}</div>", unsafe_allow_html=True)
        else:
            st.info("📎 Please upload your resume to continue")
            
        st.markdown("</div>", unsafe_allow_html=True)

    # Start interview section
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Check if ready to start
    can_start = st.session_state.resume_text and st.session_state.role and st.session_state.difficulty
    
    if can_start:
        st.markdown("""
        <div style='text-align: center; margin: 2rem 0;'>
            <div style='background: linear-gradient(135deg, #2d3748 0%, #1a202c 100%); 
                        border: 2px solid #4a5568; border-radius: 12px; padding: 1rem; margin-bottom: 1rem;'>
                <strong style='color: #81e6d9;'>Ready to start your interview!</strong>
                <p style='color: #e2e8f0; margin: 0.5rem 0 0 0;'>We'll generate 14 personalized questions based on your resume and selected role.</p>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    # Center the start button
    col_left, col_center, col_right = st.columns([1, 2, 1])
    with col_center:
        if st.button("Start Your Interview", type="primary", disabled=not can_start, use_container_width=True):
            with st.spinner("🤖 Generating personalized questions based on your profile..."):
                st.session_state.questions = generate_questions(
                    client=client,
                    resume_text=st.session_state.resume_text,
                    job_role=st.session_state.role,
                    difficulty=st.session_state.difficulty,
                    n_questions=14,
                )
            st.session_state.answers = ["" for _ in st.session_state.questions]
            st.session_state.q_idx = 0
            st.session_state.stage = "interview"
            st.rerun()
    
    st.markdown("</div>", unsafe_allow_html=True)

# -------------------- Interview --------------------
elif st.session_state.stage == "interview":
    q_idx = st.session_state.q_idx or 0
    total = len(st.session_state.questions or [])
    if total == 0:
        st.session_state.stage = "landing"
        st.rerun()

    # Header with status pills
    st.markdown("<div class='fade-in'>", unsafe_allow_html=True)
    
    # Status pills and progress
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown(f"""
        <div style='text-align: center; margin-bottom: 1rem;'>
            <span class='status-pill'>👤 {st.session_state.role}</span>
            <span class='status-pill'>📊 {st.session_state.difficulty}</span>
            <span class='status-pill'>❓ {q_idx + 1}/{total}</span>
        </div>
        """, unsafe_allow_html=True)
    
    # Progress bar with custom styling
    progress_percentage = (q_idx + 1) / total
    st.markdown(f"""
    <div style='margin: 1rem 0 2rem 0;'>
        <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;'>
            <span style='color: #4a5568; font-weight: 600;'>Interview Progress</span>
            <span style='color: #667eea; font-weight: 600;'>{int(progress_percentage * 100)}%</span>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    st.progress(progress_percentage)
    
    # Question section
    q_text = st.session_state.questions[q_idx]
    st.markdown(f"""
    <div class='question-card fade-in'>
        <h3 style='color: #2d3748; margin-bottom: 1rem; padding-left: 3rem;'>Question {q_idx + 1}</h3>
        <p style='font-size: 1.1rem; line-height: 1.6; color: #4a5568; padding-left: 3rem;'>{q_text}</p>
    </div>
    """, unsafe_allow_html=True)

    # TTS Audio section
    st.markdown("### 🔊 Listen to Question")
    audio_bytes = tts_question_to_mp3_bytes(q_text)
    if audio_bytes:
        st.audio(io.BytesIO(audio_bytes), format="audio/mp3")
        st.markdown("<p style='color: #718096; font-size: 0.9rem;'>Click play to hear the question read aloud</p>", unsafe_allow_html=True)
    else:
        st.warning("🔇 Voice playback temporarily unavailable (offline or TTS error)")

    # Answer section
    st.markdown("### ✍️ Your Answer")
    st.markdown("<p style='color: #718096; margin-bottom: 1rem;'>Take your time to provide a comprehensive answer. You can type below or use the voice recorder.</p>", unsafe_allow_html=True)
    
    st.session_state.answers[q_idx] = st.text_area(
        "Your response",
        value=st.session_state.answers[q_idx],
        key=f"answer_{q_idx}",
        height=200,
        placeholder="Start typing your answer here... Be specific and provide examples where possible.",
        label_visibility="collapsed"
    )

    # Voice recording section
    st.markdown("### 🎙️ Voice Recording (Optional)")
    st.markdown("<p style='color: #718096; margin-bottom: 1rem;'>Record your answer and it will be automatically transcribed and added to your text response.</p>", unsafe_allow_html=True)
    
    col_rec1, col_rec2 = st.columns([2, 1])
    with col_rec1:
        audio = mic_recorder(
            start_prompt="🎙️ Start Recording", 
            stop_prompt="⏹️ Stop Recording", 
            key=f"mic_{q_idx}",
            format="wav"
        )
    
    with col_rec2:
        if st.session_state.answers[q_idx].strip():
            word_count = len(st.session_state.answers[q_idx].split())
            st.metric("Word Count", f"{word_count}")
    
    if audio and isinstance(audio, dict) and audio.get("bytes"):
        with st.spinner("🤖 Transcribing your speech..."):
            transcript = transcribe_audio_with_groq(client, audio["bytes"])
            if transcript:
                # Append with proper spacing
                current_answer = st.session_state.answers[q_idx].strip()
                separator = " " if current_answer else ""
                st.session_state.answers[q_idx] = current_answer + separator + transcript
                st.success("📝 Voice transcription completed and added to your answer!")
                st.rerun()
            else:
                st.warning("⚠️ Could not transcribe audio. Please try again or continue typing your answer.")

    # Navigation section
    st.markdown("<br><hr><br>", unsafe_allow_html=True)
    
    col_nav1, col_nav2, col_nav3 = st.columns([1, 2, 1])
    
    with col_nav1:
        if q_idx > 0:
            if st.button("⬅️ Previous Question", use_container_width=True, key="prev_btn"):
                st.session_state.q_idx -= 1
                st.rerun()
        else:
            st.markdown("<div class='secondary-btn'>", unsafe_allow_html=True)
            st.button("⬅️ Previous Question", disabled=True, use_container_width=True)
            st.markdown("</div>", unsafe_allow_html=True)
    
    with col_nav2:
        # Show answer status
        answered_count = sum(1 for ans in st.session_state.answers if ans.strip())
        st.markdown(f"""
        <div style='text-align: center; padding: 1rem; background: #2d3748; border-radius: 12px; border: 2px solid #4a5568; color: #e2e8f0;'>
            <strong>Progress: {answered_count}/{total} questions answered</strong>
        </div>
        """, unsafe_allow_html=True)
    
    with col_nav3:
        if q_idx < total - 1:
            if st.button("Next Question ➡️", use_container_width=True, key="next_btn"):
                st.session_state.q_idx += 1
                st.rerun()
        else:
            st.markdown("<div class='secondary-btn'>", unsafe_allow_html=True)
            st.button("Next Question ➡️", disabled=True, use_container_width=True)
            st.markdown("</div>", unsafe_allow_html=True)
    
    # Final submit button - centered and prominent when all questions are answered
    if q_idx == total - 1:  # Only show on the last question
        st.markdown("<br><br>", unsafe_allow_html=True)
        
        # Center the finish button
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.markdown("""
            <style>
            .finish-btn {
                text-align: center;
                margin: 2rem 0;
            }
            .finish-btn button {
                background: linear-gradient(135deg, #48bb78 0%, #38a169 100%) !important;
                animation: pulse 2s infinite;
                font-size: 1.1rem !important;
                font-weight: 700 !important;
                padding: 1rem 2rem !important;
                border-radius: 50px !important;
            }
            @keyframes pulse {
                0% { box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3); }
                50% { box-shadow: 0 8px 25px rgba(72, 187, 120, 0.5); }
                100% { box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3); }
            }
            </style>
            """, unsafe_allow_html=True)
            
            st.markdown("<div class='finish-btn'>", unsafe_allow_html=True)
            if st.button("📊 Finish Interview & Get Results", type="primary", use_container_width=True):
                with st.spinner("🤖 Analyzing your responses and generating detailed feedback..."):
                    score, report_md = evaluate_answers(
                        client=client,
                        resume_text=st.session_state.resume_text,
                        job_role=st.session_state.role,
                        questions=st.session_state.questions,
                        answers=st.session_state.answers,
                    )
                    st.session_state.score = score
                    st.session_state.report = report_md
                    st.session_state.stage = "results"
                    st.rerun()
            st.markdown("</div>", unsafe_allow_html=True)
    
    st.markdown("</div>", unsafe_allow_html=True)

# -------------------- Results --------------------
elif st.session_state.stage == "results":
    st.markdown("<div class='fade-in'>", unsafe_allow_html=True)
    
    # Header section
    st.markdown("""
    <div style='text-align: center; margin-bottom: 2rem;'>
        <h1 style='color: #2d3748; margin-bottom: 0.5rem;'>🎉 Interview Complete!</h1>
        <p style='color: #718096; font-size: 1.2rem;'>Here's your detailed performance analysis</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Score section with enhanced styling
    if st.session_state.score is not None:
        score = st.session_state.score
        
        # Determine score color and message
        if score >= 80:
            score_color = "#48bb78"
            score_message = "Excellent Performance! 🌟"
            score_emoji = "🎯"
        elif score >= 60:
            score_color = "#ed8936"
            score_message = "Good Job! Room for improvement 💪"
            score_emoji = "👍"
        else:
            score_color = "#f56565"
            score_message = "Keep practicing! You'll improve 📈"
            score_emoji = "💪"
        
        # Score display card
        st.markdown(f"""
        <div style='text-align: center; margin: 2rem 0;'>
            <div style='background: linear-gradient(135deg, {score_color}15 0%, {score_color}05 100%); 
                        border: 2px solid {score_color}; border-radius: 20px; 
                        padding: 2rem; margin: 1rem auto; max-width: 400px;
                        box-shadow: 0 10px 30px {score_color}20;'>
                <div style='font-size: 4rem; margin-bottom: 0.5rem;'>{score_emoji}</div>
                <div style='font-size: 3rem; font-weight: bold; color: {score_color}; margin-bottom: 0.5rem;'>{score}/100</div>
                <div style='font-size: 1.2rem; font-weight: 600; color: #2d3748;'>{score_message}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    # Interview summary
    answered_count = sum(1 for ans in st.session_state.answers if ans.strip()) if st.session_state.answers else 0
    total_questions = len(st.session_state.questions) if st.session_state.questions else 0
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class='modern-card' style='text-align: center;'>
            <div style='font-size: 2rem; margin-bottom: 0.5rem;'>👤</div>
            <div style='font-weight: 600; color: #2d3748;'>Role</div>
            <div style='color: #667eea; font-weight: 600;'>{}</div>
        </div>
        """.format(st.session_state.role or "N/A"), unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class='modern-card' style='text-align: center;'>
            <div style='font-size: 2rem; margin-bottom: 0.5rem;'>📊</div>
            <div style='font-weight: 600; color: #2d3748;'>Difficulty</div>
            <div style='color: #667eea; font-weight: 600;'>{}</div>
        </div>
        """.format(st.session_state.difficulty or "N/A"), unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class='modern-card' style='text-align: center;'>
            <div style='font-size: 2rem; margin-bottom: 0.5rem;'>❓</div>
            <div style='font-weight: 600; color: #2d3748;'>Questions</div>
            <div style='color: #667eea; font-weight: 600;'>{answered_count}/{total_questions}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        total_words = sum(len(ans.split()) for ans in st.session_state.answers if ans.strip()) if st.session_state.answers else 0
        st.markdown(f"""
        <div class='modern-card' style='text-align: center;'>
            <div style='font-size: 2rem; margin-bottom: 0.5rem;'>📝</div>
            <div style='font-weight: 600; color: #2d3748;'>Total Words</div>
            <div style='color: #667eea; font-weight: 600;'>{total_words}</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Detailed report section
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("## 📋 Detailed Feedback Report")
    
    if st.session_state.report:
        # Custom styling for the report
        report_html = st.session_state.report.replace("###", "####")  # Adjust heading levels
        st.markdown(f"""
        <div class='modern-card' style='background: #2d3748; color: #e2e8f0;'>
            {report_html}
        </div>
        """, unsafe_allow_html=True)
    else:
        st.warning("No detailed report available.")
    
    # Action buttons section
    st.markdown("<br><hr><br>", unsafe_allow_html=True)
    
    col_action1, col_action2, col_action3 = st.columns([1, 1, 1])
    
    with col_action1:
        if st.button("� Take Another Interview", use_container_width=True, type="primary"):
            # Reset session state
            for k in ["stage", "role", "difficulty", "resume_text", "questions", "answers", "q_idx", "report", "score"]:
                if k in st.session_state:
                    del st.session_state[k]
            st.session_state.stage = "landing"
            st.rerun()
    
    with col_action2:
        # Download report button
        report_content = st.session_state.report or "No report generated"
        st.download_button(
            "📥 Download Report",
            data=report_content.encode("utf-8"),
            file_name=f"interview_report_{st.session_state.role}_{st.session_state.difficulty}.md",
            mime="text/markdown",
            use_container_width=True
        )
    
    with col_action3:
        if st.button("📧 Share Results", use_container_width=True):
            # Show sharing options
            st.balloons()
            st.success("🎉 Great job completing the interview! You can download the report above to share your results.")
    
    # Improvement suggestions
    if st.session_state.score is not None and st.session_state.score < 80:
        st.markdown("## 💡 Tips for Improvement")
        st.markdown("""
        <div class='modern-card' style='background: linear-gradient(135deg, #2d3748 0%, #1a202c 100%); border-color: #4a5568;'>
            <h4 style='color: #81e6d9; margin-bottom: 1rem;'>🚀 Level Up Your Interview Skills</h4>
            <ul style='color: #e2e8f0; line-height: 1.8;'>
                <li><strong>Practice STAR Method:</strong> Structure answers with Situation, Task, Action, Result</li>
                <li><strong>Research the Company:</strong> Show knowledge about the organization and role</li>
                <li><strong>Prepare Examples:</strong> Have specific stories ready that demonstrate your skills</li>
                <li><strong>Ask Questions:</strong> Show interest by preparing thoughtful questions</li>
                <li><strong>Mock Interviews:</strong> Practice with friends or use our simulator again</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("</div>", unsafe_allow_html=True)
